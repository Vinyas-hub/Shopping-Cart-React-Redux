import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { loginUser } from '../actions/userActions';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import ChangePassword from './ChangePassword';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const registeredUsers = useSelector((state) => state.user.registeredUsers);

  const handleLogin = () => {
    // Form validations
    if (!email || !password) {
      alert('Please enter both email and password.');
      return;
    }

    // Check if the entered email and password match any registered user's credentials
    const matchedUser = registeredUsers.find(
      (user) => user.email === email && (user.password === password || user.password === newPassword)
    );

    if (matchedUser) {
      // Check if the user entered a new password
      if (newPassword !== '') {
        // Use the new password for login
        dispatch(loginUser({ email, password: newPassword }));
      } else {
        // Use the existing password for login
        dispatch(loginUser({ email, password }));
      }
      setNewPassword(''); // Reset the newPassword state after successful login
      navigate('/shop'); // Navigate to the home page after successful login
    } else {
      alert('Invalid email or password. Please try again.');
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <p>Login to make a purchase</p>
      {/* Existing input fields */}
      <input
        type="text"
        placeholder="Username"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>
      <p>
        Don't have an account? <Link to="/register">Register</Link>
      </p>
      <p>
        Forgot your password? <Link to="/change-password">Change Password</Link>
      </p>
      {/* Render the ChangePassword component */}
      <ChangePassword />
    </div>
  );
};

export default Login;
