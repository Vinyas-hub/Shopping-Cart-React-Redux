// src/components/Home.js
import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';

const Home = () => {
  const user = useSelector((state) => state.user);

  return (
    <div>
      <h2>Welcome, {user.email}!</h2>
      <Link to="/login">Login</Link>
      <p>You are now logged in.</p>
      {user.isLoggedIn ? (
        <>
          <p>
            <Link to="/login">Login</Link>
          </p>
          <p>
            <Link to="/register">Register</Link>
          </p>
        </>
      ) : (
        <p>
          You are not logged in. Please <Link to="/register">register</Link> to access the home page.
        </p>
      )}
    </div>
  );
};

export default Home;
