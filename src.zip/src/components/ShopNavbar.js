import React from 'react';
import ChangePassword from './ChangePassword';

import Home from './Home';
import LogoutButton from './Logout';

const ShopNavbar = () => {
    return (
        <div>
           <ChangePassword/>
            <LogoutButton/>

        </div>
    );
}

export default ShopNavbar;
