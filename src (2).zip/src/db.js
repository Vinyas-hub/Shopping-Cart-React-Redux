const db = {
    products: [
      // Add your mock product data here
      {
        id: 1,
        title: 'Product 1',
        price: 10,
        //image: 'product1.jpg',
      },
      {
        id: 2,
        title: 'Product 2',
        price: 20,
       // image: 'product2.jpg',
      }
      // Add more products as needed
    ],
  };
  
  export default db;