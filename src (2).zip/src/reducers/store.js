import { configureStore } from '@reduxjs/toolkit';
import cartReducer from './cartSlice';
import productReducer from './productSlice';
import userReducer from './userSlice'; // Import the userReducer

const store = configureStore({
  reducer: {
    cart: cartReducer,
    product: productReducer,
    user: userReducer, // Add the userReducer to the reducer configuration
  },
});

export default store;
