// // src/reducers/userReducer.js
// import { createSlice } from '@reduxjs/toolkit';

// const initialState = {
//   email: '',
//   password:'',
//   isLoggedIn: false,
// };

// const userSlice = createSlice({
//   name: 'email',
//   password:'password',
//   initialState,
//   reducers: {
//     registerUser: (state, action) => {
//       state.email = action.payload.email;
//       state.password= action.payload.password;
//       state.isLoggedIn = true;
//     },
//     loginUser: (state, action) => {
//       state.email = action.payload.email;
//       state.password = action.payload.password;
//       state.isLoggedIn = true;
//     },
   
//   },
// });

// export const { registerUser, loginUser } = userSlice.actions;
// export default userSlice.reducer;
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  registeredUsers: [],
  isLoggedIn: false,
  email: '',
  password: '',
};

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    registerUser: (state, action) => {
      state.registeredUsers.push(action.payload);
    },
    loginUser: (state, action) => {
      state.email = action.payload.email;
      state.password = action.payload.password;
      state.isLoggedIn = true;
    },
    logoutUser: (state) => {
      state.isLoggedIn = false;
      state.email = '';
      state.password = '';
    },
    updatePassword: (state, action) => {
      state.password = action.payload;
    },
  },
});

export const { registerUser, loginUser, logoutUser, updatePassword } = userSlice.actions;

export default userSlice.reducer;

