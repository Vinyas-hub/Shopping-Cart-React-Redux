import React from 'react';

import { useDispatch, useSelector } from 'react-redux';

import { logoutUser } from '../reducers/userSlice';

import { useNavigate } from 'react-router-dom';




const Logout = () => {

  const dispatch = useDispatch();

  const navigate = useNavigate();

  const isLoggedIn = useSelector((state) => state.user.isLoggedIn);




  const handleLogout = () => {

    dispatch(logoutUser());

    navigate('/home'); // Redirect to the home page after logout

  };




  if (!isLoggedIn) {

    // If user is not logged in, directly redirect to home page

    navigate('/home');

    return null;

  }




  return (

    <div>

     

      <button onClick={handleLogout}>Logout</button>

    </div>

  );

};




export default Logout;
