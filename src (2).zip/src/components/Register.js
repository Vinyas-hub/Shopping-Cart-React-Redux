import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { registerUser } from '../actions/userActions';
import { useNavigate, Link } from 'react-router-dom';

const Register = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [contact, setContact] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleRegister = () => {
    if (!username || !email || !password || !contact || !city || !address) {
      setErrorMessage('All fields are required.');
      return;
    }

    if (username.length < 3) {
      setErrorMessage('Name should be at least 3 characters long.');
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setErrorMessage('Invalid email address.');
      return;
    }

    if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()]).{8,}/.test(password)) {
      setErrorMessage(
        'Password should contain at least one lowercase letter, one uppercase letter, one digit, and one special character. Minimum length: 8.'
      );
      return;
    }

    if (!/^\d{10}$/.test(contact)) {
      setErrorMessage('Contact should be a 10-digit number.');
      return;
    }

    // Additional validation for city and address can be added here

    // Dispatch the action to register the user
    dispatch(registerUser({ username, email, password, contact, city, address }));
    navigate('/login'); // Navigate to the login page after registration
  };

  return (
    <div>
      <h2>Register</h2>
      <input
        type="text"
        placeholder="Name"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="email"
        placeholder="E-mail"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <input
        type="text"
        placeholder="Contact"
        value={contact}
        onChange={(e) => setContact(e.target.value)}
      />
      <input
        type="text"
        placeholder="City"
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
      <input
        type="text"
        placeholder="Address"
        value={address}
        onChange={(e) => setAddress(e.target.value)}
      />
      <button onClick={handleRegister}>Submit</button>
      <p>
        Already have an account? <Link to="/login">Login</Link>
      </p>
      {errorMessage && <p>{errorMessage}</p>}
    </div>
  );
};

export default Register;
