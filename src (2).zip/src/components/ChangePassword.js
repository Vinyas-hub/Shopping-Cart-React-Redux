import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updatePassword } from '../actions/userActions';

const ChangePassword = () => {
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const dispatch = useDispatch();
  const email = useSelector((state) => state.user.email);
  const currentPassword = useSelector((state) => state.user.password);

  const handlePasswordChange = () => {
    // Form validations
    if (!oldPassword || !newPassword || !confirmPassword) {
      alert('Please enter all fields.');
      return;
    }

    // Check if the entered old password matches the current user's password
    if (oldPassword !== currentPassword) {
      alert('Old password is incorrect. Please try again.');
      return;
    }

    // Check if the new password and confirm password match
    if (newPassword !== confirmPassword) {
      alert('New password and confirm password do not match. Please try again.');
      return;
    }

    // Update the password in the Redux store
    dispatch(updatePassword(newPassword));
    alert('Password changed successfully.');
  };

  return (
    <div>
      <h2>Change Password</h2>
      <input
        type="password"
        placeholder="Old Password"
        value={oldPassword}
        onChange={(e) => setOldPassword(e.target.value)}
      />
      <input
        type="password"
        placeholder="New Password"
        value={newPassword}
        onChange={(e) => setNewPassword(e.target.value)}
      />
      <input
        type="password"
        placeholder="Confirm Password"
        value={confirmPassword}
        onChange={(e) => setConfirmPassword(e.target.value)}
      />
      <button onClick={handlePasswordChange}>Change Password</button>
    </div>
  );
};

export default ChangePassword;
