import React from 'react';
import ChangePassword from './ChangePassword';
import Products from './Products';
import Home from './Home';
import LogoutButton from './Logout';

const ShopNavbar = () => {
    return (
        <div>
           <ChangePassword/>
            <LogoutButton/>
<Products/>
        </div>
    );
}

export default ShopNavbar;
